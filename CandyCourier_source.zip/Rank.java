/**
 * Represents the star ranks of a courier and the features each rank unlocks.
 */
public enum Rank {
    ZERO_STAR(0, 0, 7, 6, 20, false),
    ONE_STAR(1, 100, 9, 7, 40, false),
    TWO_STAR(2, 500, 11, 8, 60, false),
    THREE_STAR(3, 1400, 13, 9, 80, true),
    FOUR_STAR(4, 3000, 15, 10, 100, true),
    FIVE_STAR(5, 5500, 15, 10, 100, true);

    private final int stars;
    private final int xpRequired;
    private final int worldSize;
    private final int productionSize;
    private final int inventoryCapacity;
    private final boolean diagonalAllowed;

    /**
     * Creates a rank.
     *
     * @param stars             the number of stars of this rank
     * @param xpRequired        the total XP needed to reach this rank
     * @param worldSize         the width/height of the world grid at this rank
     * @param productionSize    the width/height of each factory's candy grid at this rank
     * @param inventoryCapacity the number of candies the player can hold at this rank
     * @param diagonalAllowed   whether diagonal movement is unlocked at this rank
     */
    Rank(int stars, int xpRequired, int worldSize, int productionSize,
         int inventoryCapacity, boolean diagonalAllowed) {
        this.stars = stars;
        this.xpRequired = xpRequired;
        this.worldSize = worldSize;
        this.productionSize = productionSize;
        this.inventoryCapacity = inventoryCapacity;
        this.diagonalAllowed = diagonalAllowed;
    }

    /** @return the number of stars of this rank */
    public int getStars() {
        return stars;
    }

    /** @return the total XP needed to reach this rank */
    public int getXpRequired() {
        return xpRequired;
    }

    /** @return the width/height of the world grid at this rank */
    public int getWorldSize() {
        return worldSize;
    }

    /**
     * Gets how far from the home tile the player may travel in any direction.
     *
     * @return the world radius (e.g. 3 for a 7x7 world)
     */
    public int getWorldRadius() {
        return (worldSize - 1) / 2;
    }

    /** @return the width/height of each factory's candy production grid at this rank */
    public int getProductionSize() {
        return productionSize;
    }

    /** @return the number of candies the player can carry at this rank */
    public int getInventoryCapacity() {
        return inventoryCapacity;
    }

    /** @return true if diagonal movement is unlocked at this rank */
    public boolean isDiagonalAllowed() {
        return diagonalAllowed;
    }

    /**
     * Gets the rank that comes after this one.
     *
     * @return the next rank, or null if this is already the highest rank
     */
    public Rank next() {
        Rank[] all = values();
        return ordinal() + 1 < all.length ? all[ordinal() + 1] : null;
    }

    /**
     * Determines the rank that matches an amount of total XP.
     *
     * <p><b>Pre-condition:</b> totalXp is not negative.<br>
     * <b>Post-condition:</b> the highest rank whose XP requirement is met is returned.</p>
     *
     * @param totalXp the total XP earned so far
     * @return the matching rank
     */
    public static Rank forXp(int totalXp) {
        Rank result = ZERO_STAR;
        for (Rank r : values()) {
            if (totalXp >= r.xpRequired) {
                result = r;
            }
        }
        return result;
    }

    /**
     * Returns the rank written as "N-star".
     *
     * @return the readable rank label
     */
    @Override
    public String toString() {
        return stars + "-star";
    }
}
