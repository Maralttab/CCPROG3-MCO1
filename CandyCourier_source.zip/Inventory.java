import java.util.ArrayList;
import java.util.Collection;
import java.util.TreeMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/**
 * The player's bag. Every slot holds exactly one candy.
 */
public class Inventory {
    private final List<Candy> slots = new ArrayList<>();
    private int capacity;

    /**
     * Creates an empty inventory.
     *
     * <p><b>Pre-condition:</b> capacity is positive.<br>
     * <b>Post-condition:</b> an empty inventory with the given number of slots exists.</p>
     *
     * @param capacity the number of slots
     */
    public Inventory(int capacity) {
        this.capacity = capacity;
    }

    /** @return the total number of slots */
    public int getCapacity() {
        return capacity;
    }

    /**
     * Changes the number of slots (used when the player ranks up).
     *
     * <p><b>Pre-condition:</b> newCapacity is not less than the number of candies carried.<br>
     * <b>Post-condition:</b> the inventory has newCapacity slots; carried candies are unchanged.</p>
     *
     * @param newCapacity the new number of slots
     */
    public void setCapacity(int newCapacity) {
        if (newCapacity >= slots.size()) {
            this.capacity = newCapacity;
        }
    }

    /** @return the number of slots currently holding candy */
    public int getUsedSlots() {
        return slots.size();
    }

    /** @return true if no more candy can be added */
    public boolean isFull() {
        return slots.size() >= capacity;
    }

    /**
     * Adds one candy to the inventory.
     *
     * <p><b>Pre-condition:</b> candy is not null.<br>
     * <b>Post-condition:</b> the candy is stored if there was space; otherwise nothing changes.</p>
     *
     * @param candy the candy to store
     * @return true if the candy was stored, false if the inventory was full
     */
    public boolean add(Candy candy) {
        if (isFull()) {
            return false;
        }
        slots.add(candy);
        return true;
    }

    /**
     * Counts how many candies of a type are carried.
     *
     * @param type the candy type
     * @return the quantity carried
     */
    public int count(Candy type) {
        int n = 0;
        for (Candy c : slots) {
            if (c == type) {
                n++;
            }
        }
        return n;
    }

    /**
     * Checks whether the inventory has enough candy to fulfil an order.
     *
     * @param order the order to check
     * @return true if every ordered candy is carried in a sufficient quantity
     */
    public boolean hasAll(Order order) {
        for (Map.Entry<Candy, Integer> e : order.getItems().entrySet()) {
            if (count(e.getKey()) < e.getValue()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Removes the candies required by an order.
     *
     * <p><b>Pre-condition:</b> hasAll(order) is true.<br>
     * <b>Post-condition:</b> the ordered quantities of each candy are removed.</p>
     *
     * @param order the order being delivered
     */
    public void removeOrder(Order order) {
        for (Map.Entry<Candy, Integer> e : order.getItems().entrySet()) {
            for (int i = 0; i < e.getValue(); i++) {
                slots.remove(e.getKey());
            }
        }
    }

    /**
     * Gets the candy in a slot.
     *
     * @param slotNumber the 1-based slot number
     * @return the candy, or null if the slot number is not an occupied slot
     */
    public Candy getCandyAt(int slotNumber) {
        if (slotNumber < 1 || slotNumber > slots.size()) {
            return null;
        }
        return slots.get(slotNumber - 1);
    }

    /**
     * Discards the candy in one slot.
     *
     * <p><b>Post-condition:</b> the candy is removed if the slot number was valid.</p>
     *
     * @param slotNumber the 1-based slot number
     * @return the discarded candy, or null if the slot number was invalid
     */
    public Candy discard(int slotNumber) {
        if (slotNumber < 1 || slotNumber > slots.size()) {
            return null;
        }
        return slots.remove(slotNumber - 1);
    }

    /**
     * Discards the candies in several slots at once. Invalid and duplicate numbers are skipped.
     *
     * <p><b>Post-condition:</b> every distinct, valid slot number's candy is removed.</p>
     *
     * @param slotNumbers the 1-based slot numbers to discard
     * @return the candies that were discarded
     */
    public List<Candy> discardMultiple(Collection<Integer> slotNumbers) {
        TreeSet<Integer> valid = new TreeSet<>(java.util.Collections.reverseOrder());
        for (int n : slotNumbers) {
            if (n >= 1 && n <= slots.size()) {
                valid.add(n);
            }
        }
        List<Candy> removed = new ArrayList<>();
        for (int n : valid) {
            removed.add(slots.remove(n - 1));
        }
        return removed;
    }

    /**
     * Prints the numbered contents of the inventory and a summary per candy type.
     */
    public void display() {
        System.out.println("===== Inventory (" + slots.size() + "/" + capacity + " slots used) =====");
        if (slots.isEmpty()) {
            System.out.println("Your inventory is empty.");
            return;
        }
        for (int i = 0; i < slots.size(); i++) {
            System.out.println(" " + (i + 1) + ". " + slots.get(i));
        }
        Map<Candy, Integer> summary = new TreeMap<>();
        for (Candy c : slots) {
            summary.merge(c, 1, Integer::sum);
        }
        StringBuilder sb = new StringBuilder("Summary: ");
        boolean first = true;
        for (Map.Entry<Candy, Integer> e : summary.entrySet()) {
            if (!first) {
                sb.append(", ");
            }
            sb.append(e.getKey()).append(" x").append(e.getValue());
            first = false;
        }
        System.out.println(sb);
        System.out.println("Empty slots: " + (capacity - slots.size()));
    }
}
