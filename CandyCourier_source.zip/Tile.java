/**
 * One square of the world grid. A tile may hold one building.
 */
public class Tile {
    private Building building;

    /**
     * Gets the building on this tile.
     *
     * @return the building, or null if the tile is empty
     */
    public Building getBuilding() {
        return building;
    }

    /**
     * Places a building on this tile.
     *
     * <p><b>Post-condition:</b> the tile holds the given building.</p>
     *
     * @param building the building to place
     */
    public void setBuilding(Building building) {
        this.building = building;
    }
}
