import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * A factory that produces some kinds of candy in a grid of slots from which the player picks candy.
 */
public class Factory extends Building {
    /** The largest possible production grid (width and height). */
    public static final int MAX_SIZE = 10;

    /** The possible outcomes of picking up a candy from a slot. */
    public enum PickResult { SUCCESS, VACANT, INVENTORY_FULL, INVALID_TILE }

    private final Candy[][] grid = new Candy[MAX_SIZE][MAX_SIZE];
    private final List<Candy> produced;
    private final Random random;
    private int activeSize;

    /**
     * Creates a factory. Its slots start vacant until {@link #refresh()} is called.
     *
     * <p><b>Pre-condition:</b> at least one candy is given.<br>
     * <b>Post-condition:</b> a factory with a 0-star-sized, vacant grid exists.</p>
     *
     * @param name     the name of the factory
     * @param x        the x-coordinate relative to home
     * @param y        the y-coordinate relative to home
     * @param random   the random generator used to stock the grid
     * @param produced the candies (type and flavor) this factory can generate
     */
    public Factory(String name, int x, int y, Random random, List<Candy> produced) {
        super(name, x, y);
        this.random = random;
        this.produced = new ArrayList<>(produced);
        this.activeSize = Rank.ZERO_STAR.getProductionSize();
    }

    /** @return 'F' as the map symbol of a factory */
    @Override
    public char getSymbol() {
        return 'F';
    }

    /** @return a read-only list of the candies this factory can generate */
    public List<Candy> getProducedCandies() {
        return Collections.unmodifiableList(produced);
    }

    /**
     * Checks whether this factory can generate a candy.
     *
     * @param candy the candy (type and flavor)
     * @return true if the factory can generate it
     */
    public boolean produces(Candy candy) {
        return produced.contains(candy);
    }

    /** @return the current width/height of the usable grid */
    public int getActiveSize() {
        return activeSize;
    }

    /**
     * Fills every usable slot with a random candy this factory produces, replacing leftovers.
     *
     * <p><b>Post-condition:</b> no usable slot is vacant.</p>
     */
    public void refresh() {
        for (int r = 0; r < activeSize; r++) {
            for (int c = 0; c < activeSize; c++) {
                grid[r][c] = produced.get(random.nextInt(produced.size()));
            }
        }
    }

    /**
     * Enlarges the usable grid. New slots stay vacant until the next refresh.
     *
     * <p><b>Pre-condition:</b> newSize does not exceed {@link #MAX_SIZE}.<br>
     * <b>Post-condition:</b> activeSize equals newSize if it was larger than before.</p>
     *
     * @param newSize the new width/height
     */
    public void expandTo(int newSize) {
        if (newSize > activeSize && newSize <= MAX_SIZE) {
            activeSize = newSize;
        }
    }

    /**
     * Gets the candy in a slot.
     *
     * @param row the 1-based row
     * @param col the 1-based column
     * @return the candy, or null if the slot is vacant or outside the usable grid
     */
    public Candy getCandyAt(int row, int col) {
        if (row < 1 || col < 1 || row > activeSize || col > activeSize) {
            return null;
        }
        return grid[row - 1][col - 1];
    }

    /**
     * Moves a candy from a slot into the inventory.
     *
     * <p><b>Post-condition:</b> on SUCCESS the slot becomes vacant and the inventory holds the candy;
     * otherwise nothing changes.</p>
     *
     * @param row       the 1-based row
     * @param col       the 1-based column
     * @param inventory the inventory receiving the candy
     * @return the outcome of the pick-up attempt
     */
    public PickResult pickUp(int row, int col, Inventory inventory) {
        if (row < 1 || col < 1 || row > activeSize || col > activeSize) {
            return PickResult.INVALID_TILE;
        }
        Candy candy = grid[row - 1][col - 1];
        if (candy == null) {
            return PickResult.VACANT;
        }
        if (!inventory.add(candy)) {
            return PickResult.INVENTORY_FULL;
        }
        grid[row - 1][col - 1] = null;
        return PickResult.SUCCESS;
    }

    /**
     * Prints the production grid with a legend. Vacant slots are shown as "--".
     */
    public void displayGrid() {
        System.out.println("Candy production grid of " + getName() + " (" + activeSize + "x" + activeSize + "):");
        System.out.print("     ");
        for (int c = 1; c <= activeSize; c++) {
            System.out.printf("%7d", c);
        }
        System.out.println();
        for (int r = 0; r < activeSize; r++) {
            System.out.printf("%4d ", r + 1);
            for (int c = 0; c < activeSize; c++) {
                System.out.printf("%7s", grid[r][c] == null ? "--" : grid[r][c].getCode());
            }
            System.out.println();
        }
        System.out.println("Legend (-- = vacant):");
        StringBuilder line = new StringBuilder();
        int inLine = 0;
        for (Candy candy : produced) {
            line.append(String.format("  %-6s= %-22s", candy.getCode(), candy));
            inLine++;
            if (inLine == 3) {
                System.out.println(line);
                line.setLength(0);
                inLine = 0;
            }
        }
        if (inLine > 0) {
            System.out.println(line);
        }
    }

    /**
     * Asks whether to enter the factory and, if so, lets the player pick up candy.
     *
     * <p><b>Pre-condition:</b> the player is standing on this factory.<br>
     * <b>Post-condition:</b> picked candies are in the player's inventory and vacant in the grid.</p>
     *
     * @param player the visiting player
     * @param input  the console input helper
     * @return false, since a factory never ends the day
     */
    @Override
    public boolean interact(Player player, InputHelper input) {
        System.out.println("You arrived at " + getName() + ".");
        if (!input.readYesNo("Do you want to enter the factory? (y/n): ")) {
            System.out.println("You stay outside. You may stay on this tile or continue roaming.");
            return false;
        }
        boolean inside = true;
        while (inside) {
            System.out.println("--- " + getName() + " ---");
            System.out.println("1. Pick up a candy");
            System.out.println("2. Pick up multiple candies");
            System.out.println("3. Exit factory");
            int choice = input.readInt("Choose: ", 1, 3);
            if (choice == 1) {
                pickOne(player, input);
            } else if (choice == 2) {
                pickMany(player, input);
            } else {
                inside = false;
                System.out.println("You leave the factory and return to the world.");
            }
        }
        return false;
    }

    /**
     * Lets the player pick one candy by row and column.
     *
     * @param player the visiting player
     * @param input  the console input helper
     */
    private void pickOne(Player player, InputHelper input) {
        if (player.getInventory().isFull()) {
            System.out.println("Your inventory is full. Discard some candy before picking up more.");
            return;
        }
        displayGrid();
        int row = input.readInt("Row (1-" + activeSize + "): ", 1, activeSize);
        int col = input.readInt("Column (1-" + activeSize + "): ", 1, activeSize);
        Candy candy = getCandyAt(row, col);
        reportPick(row, col, candy, pickUp(row, col, player.getInventory()));
    }

    /**
     * Lets the player pick several candies in one go by typing "row,col" pairs.
     *
     * @param player the visiting player
     * @param input  the console input helper
     */
    private void pickMany(Player player, InputHelper input) {
        if (player.getInventory().isFull()) {
            System.out.println("Your inventory is full. Discard some candy before picking up more.");
            return;
        }
        displayGrid();
        String line = input.readLine("Enter tiles as row,col pairs separated by spaces (e.g. 1,2 3,4), "
                + "or leave blank to cancel: ");
        if (line.isEmpty()) {
            System.out.println("No candies picked up.");
            return;
        }
        int picked = 0;
        for (String token : line.split("\\s+")) {
            String[] parts = token.split(",");
            int row;
            int col;
            try {
                if (parts.length != 2) {
                    throw new NumberFormatException();
                }
                row = Integer.parseInt(parts[0]);
                col = Integer.parseInt(parts[1]);
            } catch (NumberFormatException e) {
                System.out.println("Ignored invalid entry: " + token);
                continue;
            }
            Candy candy = getCandyAt(row, col);
            PickResult result = pickUp(row, col, player.getInventory());
            reportPick(row, col, candy, result);
            if (result == PickResult.SUCCESS) {
                picked++;
            } else if (result == PickResult.INVENTORY_FULL) {
                System.out.println("Your inventory is full, so the remaining tiles were skipped.");
                break;
            }
        }
        System.out.println("You picked up " + picked + " candies in total.");
    }

    /**
     * Prints the feedback of one pick-up attempt.
     *
     * @param row    the 1-based row attempted
     * @param col    the 1-based column attempted
     * @param candy  the candy that was in the slot before the attempt (null if none)
     * @param result the outcome of the attempt
     */
    private void reportPick(int row, int col, Candy candy, PickResult result) {
        String tile = "(" + row + "," + col + ")";
        switch (result) {
            case SUCCESS -> System.out.println("You picked up " + candy + " from tile " + tile + ".");
            case VACANT -> System.out.println("Tile " + tile + " is vacant. Nothing to pick up.");
            case INVENTORY_FULL -> System.out.println("You don't have enough space in your inventory.");
            case INVALID_TILE -> System.out.println("Tile " + tile + " is outside the production grid.");
        }
    }
}
