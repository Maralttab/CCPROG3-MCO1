/**
 * The Candy Courier controlled by the user.
 */
public class Player {
    private final String name;
    private final Inventory inventory;
    private int x;
    private int y;
    private int totalXp;
    private int totalSteps;
    private Rank rank;

    /**
     * Creates a new 0-star player standing at the home tile.
     *
     * <p><b>Pre-condition:</b> name is not blank.<br>
     * <b>Post-condition:</b> the player is at (0, 0) with 0 XP, 0 steps and an empty inventory.</p>
     *
     * @param name the player's name
     */
    public Player(String name) {
        this.name = name;
        this.rank = Rank.ZERO_STAR;
        this.inventory = new Inventory(rank.getInventoryCapacity());
    }

    /** @return the player's name */
    public String getName() {
        return name;
    }

    /** @return the x-coordinate relative to home */
    public int getX() {
        return x;
    }

    /** @return the y-coordinate relative to home */
    public int getY() {
        return y;
    }

    /** @return the total XP earned */
    public int getTotalXp() {
        return totalXp;
    }

    /** @return the total number of steps traveled */
    public int getTotalSteps() {
        return totalSteps;
    }

    /** @return the player's current rank */
    public Rank getRank() {
        return rank;
    }

    /** @return the player's inventory */
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Moves the player to a new tile and counts one step.
     *
     * <p><b>Pre-condition:</b> the destination is inside the world and one tile away.<br>
     * <b>Post-condition:</b> the position changes and totalSteps increases by 1.</p>
     *
     * @param newX the destination x-coordinate
     * @param newY the destination y-coordinate
     */
    public void moveTo(int newX, int newY) {
        this.x = newX;
        this.y = newY;
        this.totalSteps++;
    }

    /**
     * Gives the player experience points and promotes the player when a threshold is reached.
     *
     * <p><b>Pre-condition:</b> amount is not negative.<br>
     * <b>Post-condition:</b> totalXp increases; rank and inventory capacity are updated if promoted.</p>
     *
     * @param amount the XP gained
     */
    public void addXp(int amount) {
        totalXp += amount;
        Rank newRank = Rank.forXp(totalXp);
        if (newRank != rank) {
            rank = newRank;
            inventory.setCapacity(rank.getInventoryCapacity());
        }
    }

    /**
     * Gets the XP still needed to reach the next rank.
     *
     * @return the remaining XP, or 0 if the player is already 5-star
     */
    public int getXpToNextRank() {
        Rank next = rank.next();
        return next == null ? 0 : next.getXpRequired() - totalXp;
    }
}
