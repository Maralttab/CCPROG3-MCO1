import java.util.Map;

/**
 * A house whose residents order candy to be delivered once.
 */
public class House extends Building {
    private final Order order;
    private boolean delivered;

    /**
     * Creates a house with an order.
     *
     * <p><b>Pre-condition:</b> order is not null.<br>
     * <b>Post-condition:</b> the house is waiting for its delivery.</p>
     *
     * @param name  the name of the house
     * @param x     the x-coordinate relative to home
     * @param y     the y-coordinate relative to home
     * @param order the candies ordered and the XP reward
     */
    public House(String name, int x, int y, Order order) {
        super(name, x, y);
        this.order = order;
    }

    /** @return the order of this house */
    public Order getOrder() {
        return order;
    }

    /** @return true if the order was already delivered */
    public boolean isDelivered() {
        return delivered;
    }

    /**
     * A delivered house no longer prompts the player when visited.
     *
     * @return true only while the order is still pending
     */
    @Override
    public boolean promptsOnVisit() {
        return !delivered;
    }

    /** @return 'H' for a pending house and 'h' for a delivered one */
    @Override
    public char getSymbol() {
        return delivered ? 'h' : 'H';
    }

    /**
     * Checks the player's candies and, if enough, offers to deliver the order.
     *
     * <p><b>Pre-condition:</b> the player is standing on this house.<br>
     * <b>Post-condition:</b> if the player accepts, the candies are removed, the house is marked
     * delivered and the player earns the order's XP.</p>
     *
     * @param player the visiting player
     * @param input  the console input helper
     * @return false, since a house never ends the day
     */
    @Override
    public boolean interact(Player player, InputHelper input) {
        if (delivered) {
            System.out.println(getName() + " has already received its order.");
            return false;
        }
        System.out.println("You arrived at " + getName() + ".");
        System.out.println("Order: " + order.describe() + " (reward: " + order.getXpReward() + " XP)");

        Inventory inventory = player.getInventory();
        if (!inventory.hasAll(order)) {
            System.out.println("You do not have enough candy to make this delivery yet:");
            for (Map.Entry<Candy, Integer> e : order.getItems().entrySet()) {
                int have = inventory.count(e.getKey());
                if (have < e.getValue()) {
                    System.out.println("  " + e.getKey() + ": need " + e.getValue() + ", you have " + have);
                }
            }
            System.out.println("You may stay on this tile or continue roaming.");
            return false;
        }

        if (input.readYesNo("You have enough candy. Deliver the order now? (y/n): ")) {
            inventory.removeOrder(order);
            delivered = true;
            player.addXp(order.getXpReward());
            System.out.println("Successfully delivered order to " + getName() + "! You gained "
                    + order.getXpReward() + " XP.");
        } else {
            System.out.println("Delivery postponed. You may stay on this tile or continue roaming.");
        }
        return false;
    }
}
