/**
 * The flavors a candy can have.
 */
public enum Flavor {
    UBE("Ube", "UB"),
    MANGO("Mango", "MG"),
    MACAPUNO("Macapuno", "MC"),
    PANDAN("Pandan", "PD"),
    CANDY_CORN("Candy Corn", "CC"),
    TABLEA("Tablea", "TB"),
    MELON("Melon", "ML"),
    JACKFRUIT("Jackfruit", "JF"),
    DURIAN("Durian", "DR"),
    GUYABANO("Guyabano", "GY");

    private final String displayName;
    private final String code;

    /**
     * Creates a flavor.
     *
     * @param displayName the readable name shown to the player
     * @param code        a short 2-letter code used when drawing factory grids
     */
    Flavor(String displayName, String code) {
        this.displayName = displayName;
        this.code = code;
    }

    /** @return the readable name of this flavor */
    public String getDisplayName() {
        return displayName;
    }

    /** @return the short 2-letter code used in grid displays */
    public String getCode() {
        return code;
    }

    /**
     * Returns the readable name of this flavor.
     *
     * @return the display name
     */
    @Override
    public String toString() {
        return displayName;
    }
}
