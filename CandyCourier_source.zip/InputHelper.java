import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Reads and validates console input so that the rest of the program never handles raw text.
 */
public class InputHelper {

    /** Thrown when the input stream ends while the program is still waiting for input. */
    public static class InputClosedException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        /** Creates the exception. */
        public InputClosedException() {
            super("No more input available.");
        }
    }

    private final Scanner scanner;

    /**
     * Creates an input helper.
     *
     * @param source the stream to read from (normally System.in)
     */
    public InputHelper(InputStream source) {
        this.scanner = new Scanner(source);
    }

    /**
     * Shows a prompt and reads one line.
     *
     * <p><b>Post-condition:</b> the trimmed line is returned.</p>
     *
     * @param prompt the text shown before reading
     * @return the trimmed line typed by the player
     * @throws InputClosedException if there is no more input
     */
    public String readLine(String prompt) {
        System.out.print(prompt);
        if (!scanner.hasNextLine()) {
            throw new InputClosedException();
        }
        return scanner.nextLine().trim();
    }

    /**
     * Reads a line and repeats the prompt until it is not blank.
     *
     * @param prompt the text shown before reading
     * @return a non-empty trimmed line
     */
    public String readNonEmptyLine(String prompt) {
        String line;
        do {
            line = readLine(prompt);
            if (line.isEmpty()) {
                System.out.println("Input cannot be empty.");
            }
        } while (line.isEmpty());
        return line;
    }

    /**
     * Reads an integer within a range, repeating until the input is valid.
     *
     * <p><b>Pre-condition:</b> min is not greater than max.<br>
     * <b>Post-condition:</b> an integer from min to max (inclusive) is returned.</p>
     *
     * @param prompt the text shown before reading
     * @param min    the smallest accepted value
     * @param max    the largest accepted value
     * @return the validated integer
     */
    public int readInt(String prompt, int min, int max) {
        while (true) {
            String line = readLine(prompt);
            try {
                int value = Integer.parseInt(line);
                if (value >= min && value <= max) {
                    return value;
                }
            } catch (NumberFormatException e) {
                // falls through to the error message below
            }
            System.out.println("Invalid input. Please enter a number from " + min + " to " + max + ".");
        }
    }

    /**
     * Reads a yes/no answer, repeating until the input is valid.
     *
     * @param prompt the text shown before reading
     * @return true for y/yes, false for n/no
     */
    public boolean readYesNo(String prompt) {
        while (true) {
            String line = readLine(prompt).toLowerCase();
            if (line.equals("y") || line.equals("yes")) {
                return true;
            }
            if (line.equals("n") || line.equals("no")) {
                return false;
            }
            System.out.println("Invalid input. Please answer y or n.");
        }
    }

    /**
     * Reads a list of integers separated by spaces or commas. Entries that are not numbers are ignored.
     *
     * @param prompt the text shown before reading
     * @return the numbers entered (empty if the line was blank)
     */
    public List<Integer> readIntList(String prompt) {
        String line = readLine(prompt);
        List<Integer> numbers = new ArrayList<>();
        if (line.isEmpty()) {
            return numbers;
        }
        for (String token : line.split("[\\s,]+")) {
            try {
                numbers.add(Integer.parseInt(token));
            } catch (NumberFormatException e) {
                System.out.println("Ignored invalid entry: " + token);
            }
        }
        return numbers;
    }
}
