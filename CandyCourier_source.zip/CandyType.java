/**
 * The kinds of candy produced by the factories. Some kinds come in flavors (see {@link Flavor}),
 * while others (Candy Corn and Candy Cane) have no flavor.
 */
public enum CandyType {
    GUMMY("Gummy", "GM", true),
    LOLLIPOP("Lollipop", "LP", true),
    MARSHMALLOW("Marshmallow", "MS", true),
    PASTILLAS("Pastillas", "PS", true),
    YEMA("Yema", "YM", true),
    POLVORON("Polvoron", "PV", true),
    CANDY_CORN("Candy Corn", "CN", false),
    CANDY_CANE("Candy Cane", "CA", false);

    private final String displayName;
    private final String code;
    private final boolean flavored;

    /**
     * Creates a candy type.
     *
     * @param displayName the readable name shown to the player
     * @param code        a short 2-letter code used when drawing factory grids
     * @param flavored    true if this kind of candy comes in flavors
     */
    CandyType(String displayName, String code, boolean flavored) {
        this.displayName = displayName;
        this.code = code;
        this.flavored = flavored;
    }

    /** @return the readable name of this kind of candy */
    public String getDisplayName() {
        return displayName;
    }

    /** @return the short 2-letter code used in grid displays */
    public String getCode() {
        return code;
    }

    /**
     * Tells whether this kind of candy comes in flavors.
     *
     * @return true for flavored candies; false for Candy Corn and Candy Cane
     */
    public boolean hasFlavors() {
        return flavored;
    }

    /**
     * Returns the readable name of this kind of candy.
     *
     * @return the display name
     */
    @Override
    public String toString() {
        return displayName;
    }
}
