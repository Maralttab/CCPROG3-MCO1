import java.util.Collections;
import java.util.TreeMap;
import java.util.Map;

/**
 * Represents the candies a house orders and the XP rewarded for delivering them.
 */
public class Order {
    private final Map<Candy, Integer> items = new TreeMap<>();
    private final int xpReward;

    /**
     * Creates an empty order.
     *
     * <p><b>Pre-condition:</b> xpReward is positive.<br>
     * <b>Post-condition:</b> an order with no items and the given reward exists.</p>
     *
     * @param xpReward the XP the player earns after delivering this order
     */
    public Order(int xpReward) {
        this.xpReward = xpReward;
    }

    /**
     * Adds a quantity of a candy type to this order.
     *
     * <p><b>Pre-condition:</b> type is not null and quantity is positive.<br>
     * <b>Post-condition:</b> the order requires the given quantity more of the candy.</p>
     *
     * @param type     the candy ordered (type and flavor)
     * @param quantity how many of the candy are ordered
     * @return this order, so that calls can be chained
     */
    public Order addItem(Candy type, int quantity) {
        items.merge(type, quantity, Integer::sum);
        return this;
    }

    /**
     * Gets the candies required by this order.
     *
     * @return a read-only map of candy type to required quantity
     */
    public Map<Candy, Integer> getItems() {
        return Collections.unmodifiableMap(items);
    }

    /** @return the XP rewarded for delivering this order */
    public int getXpReward() {
        return xpReward;
    }

    /**
     * Gets the total number of candies in this order.
     *
     * @return the sum of all quantities
     */
    public int getTotalQuantity() {
        int total = 0;
        for (int q : items.values()) {
            total += q;
        }
        return total;
    }

    /**
     * Describes the order as text, e.g. "3 x Lollipop, 2 x Gummy".
     *
     * @return the readable list of ordered candies
     */
    public String describe() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Candy, Integer> e : items.entrySet()) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(e.getValue()).append(" x ").append(e.getKey());
        }
        return sb.toString();
    }
}
