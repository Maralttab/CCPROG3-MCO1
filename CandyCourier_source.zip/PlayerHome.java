/**
 * The player's home at the center of the world, where the day can be ended.
 */
public class PlayerHome extends Building {

    /**
     * Creates the player's home at the center of the world.
     */
    public PlayerHome() {
        super("Your Home", 0, 0);
    }

    /** @return '@' as the map symbol of the home */
    @Override
    public char getSymbol() {
        return '@';
    }

    /**
     * Asks the player whether to call it a day.
     *
     * <p><b>Post-condition:</b> nothing changes inside this method; the caller advances the day if true.</p>
     *
     * @param player the visiting player
     * @param input  the console input helper
     * @return true if the player chose to end the day
     */
    @Override
    public boolean interact(Player player, InputHelper input) {
        System.out.println("You are at your home.");
        boolean endDay = input.readYesNo("Are you ready to call it a day? (y/n): ");
        if (!endDay) {
            System.out.println("You decide to keep going. You may stay here or continue roaming.");
        }
        return endDay;
    }
}
