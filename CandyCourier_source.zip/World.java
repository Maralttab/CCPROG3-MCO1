import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The world grid containing the home, factories and houses. Tiles are addressed with coordinates
 * relative to the player's home, which is at (0, 0); x grows to the right and y grows upward. The grid
 * is always stored at its largest size (15x15); only the part allowed by the player's rank is accessible.
 * To the player, locations are shown as a row and column (both starting at 0) of the current world.
 */
public class World {
    /** The farthest distance from home that any tile can be (for a 15x15 world). */
    public static final int MAX_RADIUS = 7;
    private static final int GRID_SIZE = 2 * MAX_RADIUS + 1;

    private final Tile[][] tiles = new Tile[GRID_SIZE][GRID_SIZE];
    private final List<Factory> factories = new ArrayList<>();
    private final List<House> houses = new ArrayList<>();
    private Rank rank = Rank.ZERO_STAR;

    /**
     * Creates an empty world at the 0-star size.
     *
     * <p><b>Post-condition:</b> every tile exists and has no building.</p>
     */
    public World() {
        for (int r = 0; r < GRID_SIZE; r++) {
            for (int c = 0; c < GRID_SIZE; c++) {
                tiles[r][c] = new Tile();
            }
        }
    }

    /**
     * Gets a tile by its coordinates relative to home.
     *
     * <p><b>Pre-condition:</b> |x| and |y| do not exceed {@link #MAX_RADIUS}.</p>
     *
     * @param x the x-coordinate relative to home
     * @param y the y-coordinate relative to home
     * @return the tile
     */
    public Tile getTile(int x, int y) {
        return tiles[MAX_RADIUS - y][x + MAX_RADIUS];
    }

    /**
     * Places the player's home.
     *
     * @param home the home building
     */
    public void setHome(PlayerHome home) {
        getTile(home.getX(), home.getY()).setBuilding(home);
    }

    /**
     * Places a factory in the world.
     *
     * <p><b>Pre-condition:</b> the tile is free.<br>
     * <b>Post-condition:</b> the factory is on its tile and registered in the world.</p>
     *
     * @param factory the factory to add
     */
    public void addFactory(Factory factory) {
        getTile(factory.getX(), factory.getY()).setBuilding(factory);
        factories.add(factory);
    }

    /**
     * Places a house in the world.
     *
     * <p><b>Pre-condition:</b> the tile is free.<br>
     * <b>Post-condition:</b> the house is on its tile and registered in the world.</p>
     *
     * @param house the house to add
     */
    public void addHouse(House house) {
        getTile(house.getX(), house.getY()).setBuilding(house);
        houses.add(house);
    }

    /** @return the distance from home to the edge of the accessible world */
    public int getRadius() {
        return rank.getWorldRadius();
    }

    /**
     * Converts a y-coordinate to a row number of the current world (row 0 is the top row).
     *
     * @param y the y-coordinate relative to home
     * @return the row number in the current world
     */
    public int getRow(int y) {
        return getRadius() - y;
    }

    /**
     * Converts an x-coordinate to a column number of the current world (column 0 is the leftmost).
     *
     * @param x the x-coordinate relative to home
     * @return the column number in the current world
     */
    public int getColumn(int x) {
        return getRadius() + x;
    }

    /**
     * Describes a location the way the player sees it, e.g. "Row 3, Column 3" for the home of a 7x7 world.
     *
     * @param x the x-coordinate relative to home
     * @param y the y-coordinate relative to home
     * @return the readable row and column
     */
    public String describeLocation(int x, int y) {
        return "Row " + getRow(y) + ", Column " + getColumn(x);
    }

    /**
     * Checks whether a coordinate is inside the accessible world. The world does not wrap around.
     *
     * @param x the x-coordinate relative to home
     * @param y the y-coordinate relative to home
     * @return true if the tile can be visited
     */
    public boolean isInBounds(int x, int y) {
        return isInBounds(x, y, rank);
    }

    /**
     * Checks whether a coordinate is inside the world of a given rank.
     *
     * @param x    the x-coordinate relative to home
     * @param y    the y-coordinate relative to home
     * @param when the rank whose world is checked
     * @return true if the tile belongs to that world
     */
    private boolean isInBounds(int x, int y, Rank when) {
        return Math.abs(x) <= when.getWorldRadius() && Math.abs(y) <= when.getWorldRadius();
    }

    /**
     * Grows the world to match a rank. Factories that become accessible are introduced fully stocked,
     * and factories that were already accessible get a larger grid whose new slots stay vacant.
     *
     * <p><b>Post-condition:</b> new tiles and factories are accessible.</p>
     *
     * @param newRank the player's new rank
     */
    public void applyRank(Rank newRank) {
        Rank previous = this.rank;
        this.rank = newRank;
        for (Factory f : factories) {
            if (isInBounds(f.getX(), f.getY())) {
                f.expandTo(newRank.getProductionSize());
                if (!isInBounds(f.getX(), f.getY(), previous)) {
                    f.refresh();
                }
            }
        }
    }

    /**
     * Restocks every accessible factory (called when a new day starts).
     *
     * <p><b>Post-condition:</b> no usable slot of an accessible factory is vacant.</p>
     */
    public void refreshFactories() {
        for (Factory f : factories) {
            if (isInBounds(f.getX(), f.getY())) {
                f.refresh();
            }
        }
    }

    /**
     * Gets every factory of the world, including those not yet accessible.
     *
     * @return a read-only list of all factories
     */
    public List<Factory> getFactories() {
        return Collections.unmodifiableList(factories);
    }

    /**
     * Gets every house of the world, including those not yet accessible.
     *
     * @return a read-only list of all houses
     */
    public List<House> getHouses() {
        return Collections.unmodifiableList(houses);
    }

    /**
     * Gets the houses that can currently be reached.
     *
     * @return the houses inside the accessible world
     */
    public List<House> getVisibleHouses() {
        List<House> visible = new ArrayList<>();
        for (House h : houses) {
            if (isInBounds(h.getX(), h.getY())) {
                visible.add(h);
            }
        }
        return visible;
    }

    /**
     * Checks whether every house in the world has received its order.
     *
     * @return true if no order is pending
     */
    public boolean allHousesDelivered() {
        for (House h : houses) {
            if (!h.isDelivered()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Finds the accessible factories that can generate a candy.
     *
     * @param candy the candy (type and flavor)
     * @return a read-only list of matching factories inside the accessible world
     */
    public List<Factory> getFactoriesProducing(Candy candy) {
        List<Factory> result = new ArrayList<>();
        for (Factory f : factories) {
            if (isInBounds(f.getX(), f.getY()) && f.produces(candy)) {
                result.add(f);
            }
        }
        return Collections.unmodifiableList(result);
    }

    /**
     * Prints the accessible part of the world with the player's position. Rows and columns are numbered
     * from 0.
     *
     * @param player the player to mark on the map
     */
    public void display(Player player) {
        int radius = getRadius();
        System.out.println("World map (" + rank.getWorldSize() + "x" + rank.getWorldSize()
                + ", rows and columns start at 0):");
        System.out.print("Col    ");
        for (int x = -radius; x <= radius; x++) {
            System.out.printf("%3d", getColumn(x));
        }
        System.out.println();
        for (int y = radius; y >= -radius; y--) {
            System.out.printf("Row %2d ", getRow(y));
            for (int x = -radius; x <= radius; x++) {
                char symbol = '.';
                Building b = getTile(x, y).getBuilding();
                if (b != null) {
                    symbol = b.getSymbol();
                }
                if (x == player.getX() && y == player.getY()) {
                    symbol = 'P';
                }
                System.out.print("  " + symbol);
            }
            System.out.println();
        }
        System.out.println("P=you  @=home  F=factory  H=house with pending order  h=delivered house  .=empty");
    }
}
