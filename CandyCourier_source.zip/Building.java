/**
 * A building that stands on one tile of the world. Coordinates are relative to the player's home,
 * which is at (0, 0); x grows to the right and y grows upward.
 */
public abstract class Building {
    private final String name;
    private final int x;
    private final int y;

    /**
     * Creates a building.
     *
     * @param name the name of the building
     * @param x    the x-coordinate relative to the home tile
     * @param y    the y-coordinate relative to the home tile
     */
    public Building(String name, int x, int y) {
        this.name = name;
        this.x = x;
        this.y = y;
    }

    /** @return the name of the building */
    public String getName() {
        return name;
    }

    /** @return the x-coordinate relative to the home tile */
    public int getX() {
        return x;
    }

    /** @return the y-coordinate relative to the home tile */
    public int getY() {
        return y;
    }

    /**
     * Gets the star rank at which the tile of this building becomes accessible. The world grows one
     * ring of tiles per rank, starting from a 7x7 world at 0-star.
     *
     * @return the rank (in stars) that unlocks this building's tile
     */
    public int getUnlockStars() {
        return Math.max(0, Math.max(Math.abs(x), Math.abs(y)) - 3);
    }

    /**
     * Tells whether landing on this building should automatically start an interaction.
     *
     * @return true by default; subclasses may return false (e.g. a completed house)
     */
    public boolean promptsOnVisit() {
        return true;
    }

    /**
     * Gets the character that represents this building on the world map.
     *
     * @return the map symbol
     */
    public abstract char getSymbol();

    /**
     * Lets the player interact with this building through the console.
     *
     * <p><b>Pre-condition:</b> the player is standing on this building's tile.<br>
     * <b>Post-condition:</b> the player's inventory/XP may have changed depending on the building.</p>
     *
     * @param player the visiting player
     * @param input  the console input helper
     * @return true if the interaction ended the day, false otherwise
     */
    public abstract boolean interact(Player player, InputHelper input);
}
