import java.util.Objects;

/**
 * One kind of candy: a {@link CandyType} with a {@link Flavor} (e.g. "Ube Lollipop"), or a plain
 * candy without a flavor (e.g. "Candy Cane"). Candies are immutable and compared by type and flavor.
 */
public class Candy implements Comparable<Candy> {
    private final CandyType type;
    private final Flavor flavor;

    /**
     * Creates a candy.
     *
     * <p><b>Pre-condition:</b> type is not null; flavor is given if and only if the type has flavors.<br>
     * <b>Post-condition:</b> an immutable candy exists.</p>
     *
     * @param type   the kind of candy
     * @param flavor the flavor, or null for candies without flavors
     * @throws IllegalArgumentException if the flavor does not match the type
     */
    public Candy(CandyType type, Flavor flavor) {
        if (type == null || type.hasFlavors() != (flavor != null)) {
            throw new IllegalArgumentException("A flavor is required exactly when the candy type has flavors.");
        }
        this.type = type;
        this.flavor = flavor;
    }

    /**
     * Creates a candy that has no flavor.
     *
     * <p><b>Pre-condition:</b> the type does not have flavors.</p>
     *
     * @param type the kind of candy (Candy Corn or Candy Cane)
     * @return the plain candy
     */
    public static Candy plain(CandyType type) {
        return new Candy(type, null);
    }

    /** @return the kind of candy */
    public CandyType getType() {
        return type;
    }

    /** @return the flavor, or null if the candy has none */
    public Flavor getFlavor() {
        return flavor;
    }

    /**
     * Gets the short code used in grid displays, e.g. "LP-UB" or "CA".
     *
     * @return the code
     */
    public String getCode() {
        return flavor == null ? type.getCode() : type.getCode() + "-" + flavor.getCode();
    }

    /**
     * Compares candies by their equal type and flavor.
     *
     * @param other the object to compare with
     * @return true if both are candies of the same type and flavor
     */
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Candy)) {
            return false;
        }
        Candy c = (Candy) other;
        return type == c.type && flavor == c.flavor;
    }

    /** @return a hash code consistent with {@link #equals(Object)} */
    @Override
    public int hashCode() {
        return Objects.hash(type, flavor);
    }

    /**
     * Orders candies by type, then by flavor (candies without a flavor first).
     *
     * @param other the candy to compare with
     * @return a negative number, zero or a positive number as this candy comes before, equals or follows other
     */
    @Override
    public int compareTo(Candy other) {
        int byType = type.compareTo(other.type);
        if (byType != 0) {
            return byType;
        }
        if (flavor == other.flavor) {
            return 0;
        }
        if (flavor == null) {
            return -1;
        }
        if (other.flavor == null) {
            return 1;
        }
        return flavor.compareTo(other.flavor);
    }

    /**
     * Returns the readable name, e.g. "Ube Lollipop" or "Candy Cane".
     *
     * @return the name of the candy
     */
    @Override
    public String toString() {
        return flavor == null ? type.toString() : flavor + " " + type;
    }
}
